#ifndef _read_write_h
#define _read_write_h

void read_write(SSL *ssl,int sock);

#endif

